# MEA Data Curation Plan

## Data status categories

Use these labels:

- `present_machine_readable`
- `present_md_needs_extraction`
- `expected_md_needs_extraction`
- `local_literature_lead`
- `source_pending`
- `not_used`
- `rejected_with_reason`

## Priority source status

| Data family | Current status | Target use | Target folder | Notes |
|---|---|---|---|---|
| Wong 2015 Raman high-pressure MEA speciation | expected_md_needs_extraction | validation first; possible Phase 2/3 target | `data/reference/MEA/ChEq/` | User says MD paper file has been added or will be added under `docs/papers/md`. |
| Amundsen 2009 CO2-loaded MEA density/viscosity | expected_md_needs_extraction | validation/regularization | `data/reference/MEA/density_viscosity/` | User says MD paper file has been added or will be added under `docs/papers/md`. |
| MEA–H2O dielectric constants | local_literature_lead | `f_solv` evidence and dielectric mixing | `data/reference/MEA/dielectric/` | Extract from existing attached/repo-local literature or cited leads. |
| loaded-MEA pH/electrochemical data | source_pending | H3O+/OH- validation only if scale is clear | `data/reference/MEA/pH/` | Requires source search and user-supplied/downloaded articles. |
| direct MEAH+ salt or carbamate salt osmotic/activity data | source_pending | independent ionic activity evidence | `data/reference/MEA/ionic_activity/` | Do not misuse ethanolammonium acetate/hexanoate as MEACOO- evidence. |

## Required extraction columns

### Wong Raman speciation

- source
- DOI
- temperature_K
- pressure_bar or pressure_kPa
- MEA_weight_fraction
- CO2_loading_molCO2_per_molMEA
- species
- value
- value_basis
- uncertainty
- extraction_method
- notes

### Amundsen density/viscosity

- source
- DOI
- temperature_K
- pressure
- MEA_weight_fraction
- CO2_loading_molCO2_per_molMEA
- density
- density_units
- viscosity
- viscosity_units
- uncertainty
- extraction_method
- notes

### MEA–H2O dielectric

- source
- DOI
- temperature_K
- pressure
- MEA_mole_fraction
- MEA_weight_fraction
- water_mole_fraction
- relative_permittivity
- uncertainty
- correlation_or_table
- notes

### pH/electrochemical

- source
- DOI
- method
- pH_scale
- temperature_K
- pressure
- MEA_weight_fraction
- CO2_loading_molCO2_per_molMEA
- pH
- calibration_notes
- usability_flag

### ionic activity/osmotic

- source
- DOI
- salt_identity
- solvent
- temperature_K
- molality
- osmotic_coefficient
- mean_ionic_activity_coefficient
- density
- uncertainty
- constrains_species
- usability_flag
