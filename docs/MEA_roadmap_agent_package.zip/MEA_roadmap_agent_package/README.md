# MEA-Thermodynamics Roadmap Agent Package

This ZIP is a repo-ready planning package for the MEA–CO2–H2O ePC-SAFT manuscript project.

It is intended to be attached to a Codex/agent prompt. The agent should copy the contents of `repo_overlay/` into the root of `tannerpolley/MEA-Thermodynamics`, then use the included prompts and roadmap files to organize the next execution slice.

## What this package contains

- `repo_overlay/docs/roadmaps/`: phase plan, dependency matrix, data curation plan, manuscript artifact plan, and acceptance gates.
- `repo_overlay/docs/prompts/MEA_ePCSAFT/`: agent prompts for ingestion, roadmap execution, and first-task execution.
- `repo_overlay/data/reference/MEA/manifests/`: CSV manifest templates for source status, figure artifacts, regression artifacts, and parameter provenance.

## What this package does not contain

- No full article text.
- No PDFs.
- No copyrighted paper content copied into the package.
- No generated model results.

The agent should use the existing repo-local Markdown papers under `docs/papers/md/` and the existing data under `data/reference/MEA/`.

## Required first agent action

Open and follow:

```text
repo_overlay/docs/prompts/MEA_ePCSAFT/INGEST_ZIP_AND_EXECUTE.md
```

## Current scientific staging

The manuscript and project roadmap must remain staged:

1. Phase 1 — Simplified Smith–Missen-style MEA reproduction baseline.
2. Phase 2 — Activity-based ePC-SAFT speciation and VLE.
3. Phase 3 — Coupled pressure/speciation regression mode.

Do not overclaim Phase 3 results unless the corresponding artifacts exist.
