# Package Contents

- `README.md`
- `repo_overlay/data/reference/MEA/manifests/figure_artifact_manifest.csv`
- `repo_overlay/data/reference/MEA/manifests/parameter_provenance_manifest.csv`
- `repo_overlay/data/reference/MEA/manifests/regression_artifact_manifest.csv`
- `repo_overlay/data/reference/MEA/manifests/source_status_manifest.csv`
- `repo_overlay/docs/prompts/MEA_ePCSAFT/CODEX_BOOTSTRAP_PROMPT.md`
- `repo_overlay/docs/prompts/MEA_ePCSAFT/FIRST_SIX_EXECUTION_STEPS.md`
- `repo_overlay/docs/prompts/MEA_ePCSAFT/INGEST_ZIP_AND_EXECUTE.md`
- `repo_overlay/docs/prompts/MEA_ePCSAFT/WEB_SOURCE_SEARCH_PROMPT_AFTER_APPROVAL.md`
- `repo_overlay/docs/roadmaps/epcsaft_dependency_matrix.md`
- `repo_overlay/docs/roadmaps/manuscript_artifact_plan.md`
- `repo_overlay/docs/roadmaps/manuscript_structure_and_figures.md`
- `repo_overlay/docs/roadmaps/mea_data_curation_plan.md`
- `repo_overlay/docs/roadmaps/mea_manuscript_phase_plan.md`
- `repo_overlay/docs/roadmaps/package_api_contract.md`
- `repo_overlay/docs/roadmaps/phase_acceptance_gates.md`
- `repo_overlay/docs/roadmaps/reaction_constant_convention_plan.md`
