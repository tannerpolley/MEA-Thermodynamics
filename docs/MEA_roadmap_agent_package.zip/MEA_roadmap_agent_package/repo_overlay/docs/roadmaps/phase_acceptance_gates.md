# Phase Acceptance Gates

## Phase 1 — Smith–Missen-style reproduction baseline

Required:

- pure CO2/MEA/H2O parameter provenance,
- MEA association scheme documented,
- MEA–H2O binary parameter documented,
- reaction constants listed with convention,
- ideal/apparent speciation runs reproducibly,
- CO2 pressure/speciation plots generated,
- limitations explicit.

Allowed claim:

> ideal/apparent-speciation reproduction baseline.

Forbidden claim:

> final true-species ePC-SAFT activity-based MEA model.

## Phase 2 — Activity-based ePC-SAFT speciation and VLE

Required:

- reaction constant conventions explicit,
- activity-based speciation enabled where constants support it,
- VLE/fugacity-equilibrium route documented,
- pressure/speciation outputs generated from one parameter artifact,
- unsupported ePC-SAFT package paths listed as package dependencies.

Allowed claim:

> activity-based true-species ePC-SAFT evaluation.

Forbidden claim:

> final coupled regression.

## Phase 3 — Coupled regression mode

Required:

- regression problem JSON,
- fit result JSON,
- parameter movement table,
- active-bound table,
- source-stratified residuals,
- target-family residuals,
- pressure and speciation generated from same final parameter artifact,
- identifiability notes.

Allowed claim:

> coupled pressure/speciation regression with newly regressed parameters.

Only if all Phase 3 artifacts exist.

Forbidden claim:

> final globally regressed parameter set.

If global fit was skipped, bounded incomplete, or used inconsistent pressure/speciation artifacts.
