# ePC-SAFT Package Dependency Matrix for MEA-Thermodynamics

## Policy

MEA-Thermodynamics must use generic ePC-SAFT APIs. It must not request application-specific public APIs.

## Dependency table

| Package capability | ePC-SAFT owner | MEA phase affected | Required for | Current action |
|---|---|---:|---|---|
| Derivative coverage gates | ePC-SAFT | 0–3 | honest capability reporting | verify current status |
| Reaction/equilibrium-constant convention layer | ePC-SAFT | 1–3 | basis-safe reaction constants | use if available |
| Generic TargetRow / TargetDataset schema | ePC-SAFT | 3 | generic regression data input | verify status |
| Explicit CppAD parameter derivatives | ePC-SAFT | 3 | native regression derivatives | verify status |
| Generic implicit solved-state sensitivities | ePC-SAFT | 2–3 | speciation/VLE/regression derivatives | verify Task C / PR #104 status |
| Generic activity-based speciation solver | ePC-SAFT | 2–3 | Phase 2 speciation | verify Task F / issue #89 status |
| Generic VLE/fugacity equilibrium solver | ePC-SAFT | 2–3 | pressure calculations | verify Task G / issue #90 status |
| Generic regression backend | ePC-SAFT | 3 | coupled regression | verify Task K / issue #94 status |
| Literature benchmark suite | ePC-SAFT | 2–3 | package confidence | verify Task L / issue #95 status |

## Do not implement in MEA-Thermodynamics

- residual Helmholtz equation internals,
- CppAD derivative plumbing,
- generic equilibrium solver internals,
- generic regression optimizer internals,
- generic TargetRow schema implementation,
- generic Ceres backend implementation.

## Do implement in MEA-Thermodynamics

- MEA data curation,
- MEA reaction network selection,
- MEA source manifests,
- MEA figure generation,
- MEA manuscript text,
- MEA phase-specific workflow scripts,
- MEA-specific wrappers around generic APIs if useful.
