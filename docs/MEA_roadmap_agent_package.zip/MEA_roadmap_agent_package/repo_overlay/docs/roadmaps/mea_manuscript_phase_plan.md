# MEA–CO2–H2O ePC-SAFT Manuscript Phase Plan

## Purpose

This roadmap organizes the MEA–CO2–H2O manuscript into staged, evidence-gated phases. It preserves the strict manuscript structure and figure plan while preventing overclaims before package and data dependencies are complete.

## Phase 0 — Repository and data inventory

Inventory:

- available data files,
- pressure data,
- speciation data,
- Jou and other VLE data,
- Wong Raman data,
- Amundsen density/viscosity data,
- MEA–H2O dielectric/permittivity data,
- pH/electrochemical candidate sources,
- direct ionic activity/osmotic candidate sources,
- current scripts,
- current parameter files,
- current figures,
- current manuscript source,
- current package import method.

Outputs:

- `docs/roadmaps/mea_data_curation_plan.md`
- `data/reference/MEA/manifests/source_status_manifest.csv`
- `data/reference/MEA/manifests/parameter_provenance_manifest.csv`

## Phase 1 — Simplified Smith–Missen-style reproduction baseline

Goal:

Replicate the basic MEA/CO2/H2O workflow used in older PC-SAFT / SAFT-HR MEA papers before adding activity-based ePC-SAFT speciation.

Use:

- pure-component PC-SAFT/ePC-SAFT parameters,
- binary parameters where needed,
- literature reaction/equilibrium constants,
- ideal or apparent Smith–Missen-style speciation,
- no ePC-SAFT activity correction inside speciation equations,
- EOS fugacity/property calculations where appropriate.

Expected outputs:

- `phase1_parameter_table.md`
- `phase1_species_basis.md`
- `phase1_reaction_constants.md`
- `phase1_speciation_validation.csv`
- `phase1_pressure_parity.csv`
- `phase1_figures/`
- `phase1_limitations.md`

Allowed claim:

> This is an ideal/apparent-speciation reproduction baseline.

Forbidden claim:

> This is the final true-species ePC-SAFT activity-based MEA model.

## Phase 2 — Activity-based ePC-SAFT speciation and VLE

Goal:

Move from ideal/apparent speciation to thermodynamic activity-based speciation using ePC-SAFT activities/fugacities.

Use:

- explicit reaction-constant conventions,
- true-species liquid basis,
- ePC-SAFT activity/fugacity/chemical-potential evaluations,
- volatile neutral vapor species only unless explicitly modeled otherwise.

Expected outputs:

- `phase2_reaction_constant_basis.md`
- `phase2_activity_speciation_problem.json`
- `phase2_equilibrium_results.csv`
- `phase2_pressure_speciation_parity.csv`
- `phase2_comparison_to_phase1.md`
- `phase2_package_dependency_matrix.md`

Allowed claim:

> This is an activity-based true-species ePC-SAFT evaluation.

Forbidden claim:

> This is a final coupled regression.

## Phase 3 — Coupled regression mode

Goal:

Allow selected reaction-equilibrium constants and selected ePC-SAFT parameters to move together if data justify it.

Fit-capable categories:

- MEAH+ sigma, epsilon, d_born,
- MEACOO- sigma, epsilon, d_born,
- HCO3- d_born,
- CO3^2- d_born,
- selected binary interaction parameters,
- MEA f_solv only with direct dielectric/activity evidence,
- reaction-equilibrium constant corrections only with explicit convention and regularization.

Expected outputs:

- `phase3_regression_problem.json`
- `phase3_fit_result.json`
- `phase3_parameter_movement.csv`
- `phase3_active_bounds.csv`
- `phase3_source_residual_summary.csv`
- `phase3_target_family_summary.csv`
- `phase3_pressure_speciation_figures/`
- `phase3_identifiability_notes.md`

Allowed claim:

> This is a coupled pressure/speciation regression only if all fit artifacts exist and all figures use the same final parameter artifact.

Forbidden claim:

> Newly regressed final parameters, if the final pressure/speciation regression was not actually executed.

## Phase 4 — Manuscript artifact generation and final audit

Goal:

Generate final manuscript figures/tables, insert them into LaTeX, and audit claims against artifacts.

Required:

- final figure CSV/PNG/SVG/YAML artifact set,
- final parameter table,
- final data manifest,
- final source provenance table,
- final train/validation summary,
- final limitations section,
- data/code availability statement,
- no local-path leakage,
- no internal agent/handoff language in manuscript.

## Strict manuscript structure

1. Introduction
2. Theory
3. Data and Methods
4. Results and Discussion
5. Conclusions
6. Data and Code Availability
7. Supporting Information

Do not alter the manuscript spine without explicit user approval.
